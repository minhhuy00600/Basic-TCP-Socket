#include<iostream>
#include<WinSock2.h>
#include<string>
#include<stdio.h>
#include<tchar.h>
#include<WS2tcpip.h>

#pragma comment (lib, "Ws2_32.lib")
#define _WINSOCK_DEPRECATED_NO_WARNINGS

using namespace std;
